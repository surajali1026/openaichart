# OpenAIChart (Android)

OpenAIChart is an Android trading-chart application built with Kotlin and Jetpack Compose. The supplied project includes Binance market data, candle history/live updates, timeframe selection, drawing tools, watchlists/markets, and price-alert monitoring.

## Improvements in this package

- On-chart movable **+ Alert** control: drag it to a price level to prefill the alert price, or tap it to start an alert at the current market price.
- Drawing edit fix: selected drawing handles and drawing bodies now update from the latest in-progress drawing state while dragging, preventing repeated drag deltas from snapping back to the original geometry.
- Existing chart interactions retained: two-finger pinch zoom, one-finger chart pan, price-scale adjustment, time-axis candle-width adjustment, and drawing tools.
- GitHub Actions workflow builds a debug APK and uploads it as an Actions artifact.

## Build with GitHub Actions

1. Upload the full contents of this repository to the `main` branch of `surajali1026/openaichart`.
2. Open **Actions** in GitHub and select **Build OpenAIChart APK**.
3. Wait for the workflow to finish successfully.
4. Open the completed run and download the `OpenAIChart-debug-apk` artifact.
5. Extract the ZIP and install the APK on your Android phone. Allow installation from your browser/files app if Android asks.

A failed workflow means the APK was not produced; check the failing step's log before trying to install anything.

## Build locally

Open this folder in Android Studio, allow Gradle sync, then run the `app` configuration or use `gradle assembleDebug` with Android SDK platform 36.1 and build tools 36.0.0 installed.

## Important

- This is an unsigned-for-release **debug APK** intended for testing. A production release requires a separate signing key.
- Never upload API keys, `.env`, signing keystores, passwords, or private tokens to GitHub.
- Binance market data requires an internet connection. Alert monitoring behaviour depends on Android background-service and notification permissions.
